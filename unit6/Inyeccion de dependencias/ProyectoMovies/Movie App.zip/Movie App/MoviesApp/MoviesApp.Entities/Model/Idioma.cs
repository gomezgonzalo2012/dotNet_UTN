﻿namespace MoviesApp.Entities.Model
{
    public class Idioma
    {
        public string Name {  get; set; }
        public Idioma(string name)
        {
            Name = name;
        }   
    }
}